package com.cihazbilgisi.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ConfigurationInfo;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Size;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import java.util.TreeSet;

public class MainActivity extends Activity implements SensorEventListener {
  static final int BG = 0xFF0B0E11, CARD = 0xFF131A20, LINE = 0xFF212B33, TX = 0xFFD9E1E6, MU = 0xFF7B8893, AC = 0xFF1C9FAE;
  final String[] N = {"Özet", "Donanım", "Ekran", "Yazılım", "Ağ & Pil", "Sensörler"};
  LinearLayout content; ScrollView scroll; TextView[] tabs; int tab = 0;
  SensorManager sm;
  float[] acc = new float[3], gyr = new float[3], mag = new float[3];
  float light = -1, press = -1, prox = -1;
  boolean gotAcc, gotGyr, gotMag;
  Handler h = new Handler(Looper.getMainLooper());
  Runnable tick = new Runnable() { public void run() { if (tab == 0 || tab == 4 || tab == 5) render(true); h.postDelayed(this, 1000); } };

  int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
  TextView tv(String s, int c, float sp, boolean bold) {
    TextView t = new TextView(this); t.setText(s); t.setTextColor(c); t.setTextSize(sp);
    if (bold) t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); return t; }
  LinearLayout card(String title) {
    LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
    GradientDrawable g = new GradientDrawable(); g.setColor(CARD); g.setCornerRadius(dp(14)); g.setStroke(dp(1), LINE);
    c.setBackground(g); c.setPadding(dp(14), dp(12), dp(14), dp(8));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(12)); c.setLayoutParams(lp);
    TextView t = tv(title.toUpperCase(new Locale("tr")), AC, 11, true); t.setLetterSpacing(.1f); c.addView(t);
    content.addView(c); return c; }
  void row(LinearLayout c, String k, String v) {
    LinearLayout r = new LinearLayout(this); r.setPadding(0, dp(7), 0, dp(7));
    TextView a = tv(k, MU, 13, false);
    TextView b = tv(v == null || v.isEmpty() ? "—" : v, TX, 13, false); b.setGravity(Gravity.END); b.setTypeface(Typeface.MONOSPACE);
    r.addView(a, new LinearLayout.LayoutParams(-2, -2));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.leftMargin = dp(12); r.addView(b, lp);
    c.addView(r); }
  void cardKV(String title, String... kv) { LinearLayout c = card(title); for (int i = 0; i + 1 < kv.length; i += 2) row(c, kv[i], kv[i + 1]); }
  void bar(LinearLayout c, int p) {
    p = Math.max(0, Math.min(100, p)); LinearLayout b = new LinearLayout(this);
    View a = new View(this), z = new View(this); a.setBackgroundColor(AC); z.setBackgroundColor(LINE);
    b.addView(a, new LinearLayout.LayoutParams(0, dp(6), p)); b.addView(z, new LinearLayout.LayoutParams(0, dp(6), 100 - p));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(6)); lp.setMargins(0, dp(2), 0, dp(8)); c.addView(b, lp); }

  protected void onCreate(Bundle sv) {
    super.onCreate(sv);
    getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(0xFF0E1317);
    LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); root.setFitsSystemWindows(true);
    TextView hd = tv("Cihaz Bilgisi", TX, 18, true); hd.setPadding(dp(16), dp(12), dp(16), dp(10)); root.addView(hd);
    scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
    content.setPadding(dp(14), dp(14), dp(14), dp(8)); scroll.addView(content);
    root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    LinearLayout nav = new LinearLayout(this); nav.setBackgroundColor(0xFF0E1317); tabs = new TextView[N.length];
    for (int i = 0; i < N.length; i++) {
      final int k = i; TextView t = tv(N[i], MU, 11, false); t.setGravity(Gravity.CENTER); t.setPadding(0, dp(14), 0, dp(14));
      t.setOnClickListener(v -> { tab = k; render(false); }); tabs[i] = t; nav.addView(t, new LinearLayout.LayoutParams(0, -2, 1)); }
    root.addView(nav); setContentView(root);
    sm = (SensorManager) getSystemService(SENSOR_SERVICE); render(false); }

  protected void onResume() {
    super.onResume();
    for (int t : new int[]{Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GYROSCOPE, Sensor.TYPE_MAGNETIC_FIELD, Sensor.TYPE_LIGHT, Sensor.TYPE_PRESSURE, Sensor.TYPE_PROXIMITY}) {
      Sensor s = sm.getDefaultSensor(t); if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI); }
    h.removeCallbacks(tick); h.post(tick); }
  protected void onPause() { super.onPause(); sm.unregisterListener(this); h.removeCallbacks(tick); }

  public void onSensorChanged(SensorEvent e) {
    switch (e.sensor.getType()) {
      case Sensor.TYPE_ACCELEROMETER: System.arraycopy(e.values, 0, acc, 0, 3); gotAcc = true; break;
      case Sensor.TYPE_GYROSCOPE: System.arraycopy(e.values, 0, gyr, 0, 3); gotGyr = true; break;
      case Sensor.TYPE_MAGNETIC_FIELD: System.arraycopy(e.values, 0, mag, 0, 3); gotMag = true; break;
      case Sensor.TYPE_LIGHT: light = e.values[0]; break;
      case Sensor.TYPE_PRESSURE: press = e.values[0]; break;
      case Sensor.TYPE_PROXIMITY: prox = e.values[0]; break; } }
  public void onAccuracyChanged(Sensor s, int a) {}

  void render(boolean keep) {
    final int y = scroll.getScrollY(); content.removeAllViews();
    for (int i = 0; i < tabs.length; i++) tabs[i].setTextColor(i == tab ? AC : MU);
    try { switch (tab) { case 0: ozet(); break; case 1: donanim(); break; case 2: ekran(); break; case 3: yazilim(); break; case 4: pil(); net(); break; default: sensor(); } }
    catch (Exception e) { cardKV("Hata", "Ayrıntı", String.valueOf(e)); }
    if (keep) scroll.post(() -> scroll.scrollTo(0, y)); else scroll.scrollTo(0, 0); }

  String rf(String p) { try (BufferedReader r = new BufferedReader(new FileReader(p))) { return r.readLine(); } catch (Exception e) { return null; } }
  String cpuinfo(String key) {
    try (BufferedReader r = new BufferedReader(new FileReader("/proc/cpuinfo"))) { String l;
      while ((l = r.readLine()) != null) if (l.startsWith(key)) { int i = l.indexOf(':'); if (i > 0) return l.substring(i + 1).trim(); } } catch (Exception e) {} return null; }
  String gb(long b) { return String.format(Locale.US, "%.1f GB", b / 1073741824.0); }
  String f(float v) { return String.format(Locale.US, "%.2f", v); }
  String v3(float[] a) { return f(a[0]) + " / " + f(a[1]) + " / " + f(a[2]); }
  long[] mem() { ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo(); ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m); return new long[]{m.totalMem, m.availMem}; }
  long[] disk() { StatFs s = new StatFs(Environment.getDataDirectory().getPath()); return new long[]{s.getTotalBytes(), s.getAvailableBytes()}; }
  Intent batt() { return registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); }
  int pct() { Intent i = batt(); if (i == null) return -1; return i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / Math.max(1, i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)); }
  String soc() {
    String s = null;
    if (Build.VERSION.SDK_INT >= 31) { String m = Build.SOC_MODEL; if (m != null && !m.equals("unknown")) s = Build.SOC_MANUFACTURER + " " + m; }
    if (s == null) s = cpuinfo("Hardware"); if (s == null) s = Build.HARDWARE; return s; }
  String freqs(String f) {
    int n = Runtime.getRuntime().availableProcessors(); TreeMap<Integer, Integer> m = new TreeMap<>();
    for (int i = 0; i < n; i++) { String v = rf("/sys/devices/system/cpu/cpu" + i + "/cpufreq/" + f); if (v == null) continue;
      try { m.merge(Integer.parseInt(v.trim()) / 1000, 1, Integer::sum); } catch (Exception e) {} }
    if (m.isEmpty()) return null; StringBuilder sb = new StringBuilder();
    for (Integer k : m.keySet()) { if (sb.length() > 0) sb.append(", "); sb.append(m.get(k)).append("×").append(k).append(" MHz"); } return sb.toString(); }
  String cams() {
    try { CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE); StringBuilder sb = new StringBuilder();
      for (String id : cm.getCameraIdList()) { CameraCharacteristics c = cm.getCameraCharacteristics(id);
        Integer lf = c.get(CameraCharacteristics.LENS_FACING); Size s = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
        if (sb.length() > 0) sb.append("\n"); sb.append(id).append(": ").append(lf == null ? "?" : lf == 0 ? "Ön" : lf == 1 ? "Arka" : "Harici");
        if (s != null) sb.append(" ").append(String.format(Locale.US, "%.1f MP", s.getWidth() * (double) s.getHeight() / 1e6)); }
      return sb.length() == 0 ? null : sb.toString(); } catch (Exception e) { return null; } }
  String bst(int s) { switch (s) { case 2: return "Şarj oluyor"; case 3: return "Boşalıyor"; case 4: return "Şarj olmuyor"; case 5: return "Dolu"; default: return "Bilinmiyor"; } }
  String bhl(int s) { switch (s) { case 2: return "İyi"; case 3: return "Aşırı ısınmış"; case 4: return "Arızalı"; case 5: return "Aşırı voltaj"; case 7: return "Soğuk"; default: return "Bilinmiyor"; } }
  String bpl(int p) { if (p == 0) return "Pilden"; if ((p & 1) != 0) return "Şebeke (AC)"; if ((p & 2) != 0) return "USB"; if ((p & 4) != 0) return "Kablosuz"; return "Diğer"; }

  void ozet() {
    long[] m = mem(), d = disk(); int p = pct();
    cardKV("Cihaz", "Model", Build.MANUFACTURER + " " + Build.MODEL, "Android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")", "İşlemci", soc(), "Çekirdek", "" + Runtime.getRuntime().availableProcessors());
    LinearLayout c = card("Bellek (RAM)"); row(c, "Toplam", gb(m[0])); row(c, "Kullanılabilir", gb(m[1])); bar(c, 100 - (int) (m[1] * 100 / m[0]));
    c = card("Depolama"); row(c, "Toplam", gb(d[0])); row(c, "Boş", gb(d[1])); bar(c, 100 - (int) (d[1] * 100 / d[0]));
    c = card("Pil"); row(c, "Seviye", "%" + p); bar(c, p); }

  void donanim() {
    long[] m = mem(), d = disk(); ConfigurationInfo ci = ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getDeviceConfigurationInfo();
    cardKV("İşlemci", "SoC", soc(), "Kart (board)", Build.BOARD, "Donanım", Build.HARDWARE, "Çekirdek sayısı", "" + Runtime.getRuntime().availableProcessors(),
      "Maks. frekans", freqs("cpuinfo_max_freq"), "Anlık frekans", freqs("scaling_cur_freq"), "Mimari (ABI)", String.join(", ", Build.SUPPORTED_ABIS));
    cardKV("Bellek ve Depolama", "RAM toplam", gb(m[0]), "RAM kullanılabilir", gb(m[1]), "Dahili depolama", gb(d[0]), "Boş alan", gb(d[1]));
    cardKV("Grafik", "OpenGL ES", ci.getGlEsVersion(), "Vulkan", getPackageManager().hasSystemFeature("android.hardware.vulkan.version") ? "Var" : "Yok");
    cardKV("Kameralar", "Liste", cams());
    String[][] F = {{"NFC", "android.hardware.nfc"}, {"Bluetooth", "android.hardware.bluetooth"}, {"Bluetooth LE", "android.hardware.bluetooth_le"}, {"Wi-Fi", "android.hardware.wifi"},
      {"GPS", "android.hardware.location.gps"}, {"Parmak izi", "android.hardware.fingerprint"}, {"Telefon", "android.hardware.telephony"}, {"Kızılötesi", "android.hardware.consumerir"},
      {"Çoklu dokunma", "android.hardware.touchscreen.multitouch"}, {"USB host", "android.hardware.usb.host"}, {"Kamera flaşı", "android.hardware.camera.flash"}};
    LinearLayout c = card("Özellikler"); for (String[] x : F) row(c, x[0], getPackageManager().hasSystemFeature(x[1]) ? "Var" : "Yok"); }

  void ekran() {
    DisplayMetrics dm = new DisplayMetrics(); Display d = getWindowManager().getDefaultDisplay(); d.getRealMetrics(dm);
    double in = Math.sqrt(Math.pow(dm.widthPixels / dm.xdpi, 2) + Math.pow(dm.heightPixels / dm.ydpi, 2));
    TreeSet<Integer> hz = new TreeSet<>(); for (Display.Mode m : d.getSupportedModes()) hz.add(Math.round(m.getRefreshRate()));
    cardKV("Panel", "Çözünürlük", dm.widthPixels + " × " + dm.heightPixels, "Boyut (yaklaşık)", String.format(Locale.US, "%.1f inç", in), "Yoğunluk", dm.densityDpi + " dpi",
      "Ölçek", dm.density + "x", "Yenileme hızı", String.format(Locale.US, "%.0f Hz", d.getRefreshRate()), "Desteklenen modlar", hz.toString().replace("[", "").replace("]", "") + " Hz",
      "Yönelim", getResources().getConfiguration().orientation == 2 ? "Yatay" : "Dikey", "Ekran adı", d.getName()); }

  void yazilim() {
    long up = SystemClock.elapsedRealtime() / 1000;
    cardKV("Android", "Sürüm", Build.VERSION.RELEASE, "API seviyesi", "" + Build.VERSION.SDK_INT, "Güvenlik yaması", Build.VERSION.SECURITY_PATCH, "Derleme", Build.DISPLAY, "Artımlı", Build.VERSION.INCREMENTAL, "Tür / Etiket", Build.TYPE + " / " + Build.TAGS);
    cardKV("Sistem", "Çekirdek (kernel)", System.getProperty("os.version"), "Bootloader", Build.BOOTLOADER, "Java VM", System.getProperty("java.vm.version"),
      "Açık kalma süresi", (up / 3600) + " sa " + ((up % 3600) / 60) + " dk", "Dil", Locale.getDefault().toString(), "Saat dilimi", java.util.TimeZone.getDefault().getID());
    cardKV("Üretici", "Marka", Build.BRAND, "Üretici", Build.MANUFACTURER, "Cihaz kodu", Build.DEVICE, "Ürün", Build.PRODUCT, "Parmak izi (fingerprint)", Build.FINGERPRINT); }

  void pil() {
    Intent i = batt(); if (i == null) { cardKV("Pil", "Durum", "Okunamadı"); return; }
    int p = pct(); LinearLayout c = card("Pil"); row(c, "Seviye", "%" + p); bar(c, p);
    row(c, "Durum", bst(i.getIntExtra(BatteryManager.EXTRA_STATUS, 1))); row(c, "Güç kaynağı", bpl(i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)));
    row(c, "Sağlık", bhl(i.getIntExtra(BatteryManager.EXTRA_HEALTH, 1))); row(c, "Sıcaklık", (i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0) + " °C");
    row(c, "Voltaj", i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) + " mV"); row(c, "Teknoloji", i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)); }

  void net() {
    ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE); Network n = cm.getActiveNetwork();
    NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
    if (nc == null) { cardKV("Bağlantı", "Durum", "Bağlantı yok"); return; }
    String t = nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi" : nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Mobil veri" : nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "Ethernet" : "Diğer";
    cardKV("Bağlantı", "Durum", "Bağlı", "Tür", t, "İndirme (tahmini)", nc.getLinkDownstreamBandwidthKbps() / 1000 + " Mbps", "Yükleme (tahmini)", nc.getLinkUpstreamBandwidthKbps() / 1000 + " Mbps",
      "İnternet", nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ? "Doğrulandı" : "Doğrulanamadı", "VPN", nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ? "Var" : "Yok"); }

  String heading() {
    if (!gotAcc || !gotMag) return null; float[] R = new float[9], o = new float[3];
    if (!SensorManager.getRotationMatrix(R, null, acc, mag)) return null; SensorManager.getOrientation(R, o);
    float a = (float) ((Math.toDegrees(o[0]) + 360) % 360); String[] d = {"K", "KD", "D", "GD", "G", "GB", "B", "KB"};
    return Math.round(a) + "° " + d[Math.round(a / 45f) % 8]; }

  void sensor() {
    LinearLayout c = card("Canlı Veriler");
    row(c, "İvmeölçer (m/s²)", gotAcc ? v3(acc) : null); row(c, "Jiroskop (rad/s)", gotGyr ? v3(gyr) : null); row(c, "Manyetometre (µT)", gotMag ? v3(mag) : null);
    row(c, "Pusula", heading()); row(c, "Işık (lx)", light < 0 ? null : f(light)); row(c, "Basınç (hPa)", press < 0 ? null : f(press)); row(c, "Yakınlık (cm)", prox < 0 ? null : f(prox));
    List<Sensor> l = sm.getSensorList(Sensor.TYPE_ALL); c = card("Cihazdaki Sensörler (" + l.size() + ")");
    for (Sensor s : l) { String t = s.getStringType(); row(c, t.substring(t.lastIndexOf('.') + 1), s.getName() + " · " + s.getVendor()); } }
}
