package com.cihazbilgisi.app;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ConfigurationInfo;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Size;
import android.util.TypedValue;
import android.view.Choreographer;
import android.view.Display;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.view.animation.OvershootInterpolator;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import java.util.TreeSet;

public class MainActivity extends Activity implements SensorEventListener {
  static final int BG = 0xFF0B0E11, CARD = 0xFF131A20, LINE = 0xFF212B33, TX = 0xFFD9E1E6, MU = 0xFF7B8893, AC = 0xFF1C9FAE;
  final String[] N = {"Özet", "Donanım", "Ekran", "Yazılım", "Ağ & Pil", "Sensörler"};
  LinearLayout content; Pager pager; Nav nav; ScrollView[] pg = new ScrollView[6]; LinearLayout[] pc = new LinearLayout[6];
  TextView[] tabs; Drawable[] ics; float[] ringStore = new float[3];
  SensorManager sm;
  float[] acc = new float[3], gyr = new float[3], mag = new float[3], fa = new float[3], fm = new float[3], dAcc = new float[3], dGyr = new float[3], dMag = new float[3];
  float light = -1, press = -1, prox = -1, hdD = Float.NaN; int fcnt = 0;
  boolean gotAcc, gotGyr, gotMag;
  Compass cp; Axis ax, gy, mg; TextView tLux, tHpa, tProx;
  Handler h = new Handler(Looper.getMainLooper());
  Runnable tick = new Runnable() { public void run() {
    if (pager != null) { if (pager.pos < 1f) renderPage(0, true); if (pager.pos > 3f && pager.pos < 5f) renderPage(4, true); }
    h.postDelayed(this, 1000); } };
  Choreographer.FrameCallback fcb = new Choreographer.FrameCallback() { long last;
    public void doFrame(long t) { float dt = last == 0 ? .016f : Math.min(.05f, (t - last) / 1e9f); last = t; frame(dt); Choreographer.getInstance().postFrameCallback(this); } };

  // ---------- özel görünümler ----------
  static class Ring extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); float d, shown; int pct, idx; float[] store; String label, sub;
    Ring(Context x, String label, String sub, int pct, float[] store, int idx) { super(x); d = x.getResources().getDisplayMetrics().density; this.label = label; this.sub = sub;
      this.pct = Math.max(0, Math.min(100, pct)); this.store = store; this.idx = idx; shown = store[idx]; }
    protected void onMeasure(int w, int hh) { int W = MeasureSpec.getSize(w); setMeasuredDimension(W, (int) (W + 36 * d)); }
    protected void onDraw(Canvas c) {
      float diff = pct - shown; if (Math.abs(diff) > .2f) { shown += diff * .12f; postInvalidateOnAnimation(); } else shown = pct; store[idx] = shown;
      float W = getWidth(), pad = 12 * d, sw = 9 * d, cx = W / 2;
      RectF r = new RectF(pad + sw / 2, pad + sw / 2, W - pad - sw / 2, W - pad - sw / 2);
      p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); p.setStrokeCap(Paint.Cap.ROUND);
      p.setColor(LINE); c.drawArc(r, 0, 360, false, p); p.setColor(AC); if (shown > .5f) c.drawArc(r, -90, 360f * shown / 100, false, p);
      p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER);
      p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)); p.setTextSize(17 * d); p.setColor(TX); c.drawText("%" + Math.round(shown), cx, W / 2 + 6 * d, p);
      p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(13 * d); p.setColor(TX); c.drawText(label, cx, W + 6 * d, p);
      p.setTypeface(Typeface.DEFAULT); p.setTextSize(11 * d); p.setColor(MU); c.drawText(sub, cx, W + 24 * d, p); } }

  static class Compass extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); float d, hd = Float.NaN;
    Compass(Context x) { super(x); d = x.getResources().getDisplayMetrics().density; }
    void set(float v) { hd = v; invalidate(); }
    protected void onDraw(Canvas c) {
      float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 18 * d;
      p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2 * d); p.setColor(LINE); c.drawCircle(cx, cy, r, p);
      String[] L = {"K", "D", "G", "B"};
      c.save(); c.rotate(Float.isNaN(hd) ? 0 : -hd, cx, cy);
      for (int a = 0; a < 360; a += 5) {
        boolean M = a % 90 == 0, m = a % 30 == 0; float len = M ? 14 * d : (m ? 10 * d : 5 * d);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth((M ? 2.5f : 1.5f) * d); p.setColor(M ? AC : (m ? MU : LINE)); c.drawLine(cx, cy - r, cx, cy - r + len, p);
        if (M) { p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
          p.setTextSize(18 * d); p.setColor(a == 0 ? AC : TX); c.drawText(L[a / 90], cx, cy - r + 40 * d, p); }
        c.rotate(5, cx, cy); }
      c.restore();
      Path t = new Path(); t.moveTo(cx - 8 * d, cy - r - 14 * d); t.lineTo(cx + 8 * d, cy - r - 14 * d); t.lineTo(cx, cy - r - 1 * d); t.close();
      p.setStyle(Paint.Style.FILL); p.setColor(TX); c.drawPath(t, p);
      p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)); p.setTextSize(36 * d); p.setColor(TX);
      c.drawText(Float.isNaN(hd) ? "—" : Math.round(hd) % 360 + "°", cx, cy + 10 * d, p);
      String[] D = {"Kuzey", "Kuzeydoğu", "Doğu", "Güneydoğu", "Güney", "Güneybatı", "Batı", "Kuzeybatı"};
      p.setTypeface(Typeface.DEFAULT); p.setTextSize(14 * d); p.setColor(MU);
      c.drawText(Float.isNaN(hd) ? "Sensör bekleniyor" : D[Math.round(hd / 45f) % 8], cx, cy + 36 * d, p); } }

  static class Axis extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); float d, max; float[] v = new float[3]; boolean ok;
    Axis(Context x, float max) { super(x); d = x.getResources().getDisplayMetrics().density; this.max = max; }
    void set(float[] a, boolean ok) { System.arraycopy(a, 0, v, 0, 3); this.ok = ok; invalidate(); }
    protected void onDraw(Canvas c) {
      float W = getWidth(), rh = getHeight() / 3f, x0 = 26 * d, x1 = W - 74 * d, mid = (x0 + x1) / 2; String[] n = {"X", "Y", "Z"};
      for (int i = 0; i < 3; i++) {
        float cy = rh * i + rh / 2;
        p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)); p.setTextSize(14 * d); p.setColor(AC); c.drawText(n[i], 0, cy + 5 * d, p);
        p.setColor(LINE); c.drawRoundRect(new RectF(x0, cy - 4 * d, x1, cy + 4 * d), 4 * d, 4 * d, p);
        if (ok) { float f = Math.max(-1f, Math.min(1f, v[i] / max)), e = mid + f * (x1 - x0) / 2; p.setColor(AC);
          c.drawRoundRect(new RectF(Math.min(mid, e), cy - 4 * d, Math.max(mid, e) + 1, cy + 4 * d), 4 * d, 4 * d, p); }
        p.setColor(MU); c.drawRect(mid - 0.75f * d, cy - 8 * d, mid + 0.75f * d, cy + 8 * d, p);
        p.setTextAlign(Paint.Align.RIGHT); p.setTypeface(Typeface.MONOSPACE); p.setTextSize(13 * d); p.setColor(TX);
        c.drawText(ok ? String.format(Locale.US, "%.2f", v[i]) : "—", W, cy + 5 * d, p); } } }

  // ---------- yardımcılar ----------
  int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
  TextView tv(String s, int c, float sp, boolean bold) {
    TextView t = new TextView(this); t.setText(s); t.setTextColor(c); t.setTextSize(sp);
    if (bold) t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); return t; }
  GradientDrawable bg(int color, int stroke, int rad) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(rad)); if (stroke != 0) g.setStroke(dp(1), stroke); return g; }
  LinearLayout card(String title) {
    LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setBackground(bg(CARD, LINE, 14)); c.setPadding(dp(14), dp(12), dp(14), dp(8));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(12)); c.setLayoutParams(lp);
    if (title != null) { TextView t = tv(title.toUpperCase(new Locale("tr")), AC, 11, true); t.setLetterSpacing(.1f); t.setPadding(0, 0, 0, dp(4)); c.addView(t); }
    content.addView(c); return c; }
  void row(LinearLayout c, String k, String v) {
    LinearLayout r = new LinearLayout(this); r.setPadding(0, dp(7), 0, dp(7));
    TextView a = tv(k, MU, 13, false);
    TextView b = tv(v == null || v.isEmpty() ? "—" : v, TX, 13, false); b.setGravity(Gravity.END); b.setTypeface(Typeface.MONOSPACE);
    r.addView(a, new LinearLayout.LayoutParams(-2, -2));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.leftMargin = dp(12); r.addView(b, lp); c.addView(r); }
  void cardKV(String title, String... kv) { LinearLayout c = card(title); for (int i = 0; i + 1 < kv.length; i += 2) row(c, kv[i], kv[i + 1]); }
  void bar(LinearLayout c, int p) {
    p = Math.max(0, Math.min(100, p)); LinearLayout b = new LinearLayout(this);
    View a = new View(this), z = new View(this); a.setBackgroundColor(AC); z.setBackgroundColor(LINE);
    b.addView(a, new LinearLayout.LayoutParams(0, dp(6), p)); b.addView(z, new LinearLayout.LayoutParams(0, dp(6), 100 - p));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(6)); lp.setMargins(0, dp(2), 0, dp(8)); c.addView(b, lp); }
  LinearLayout hrow() { LinearLayout r = new LinearLayout(this); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(-dp(4), 0, -dp(4), dp(8)); r.setLayoutParams(lp); content.addView(r); return r; }
  TextView tile(LinearLayout r, String title, String val) {
    LinearLayout t = new LinearLayout(this); t.setOrientation(LinearLayout.VERTICAL); t.setBackground(bg(CARD, LINE, 14)); t.setPadding(dp(14), dp(12), dp(14), dp(12));
    TextView a = tv(title, MU, 11, false); TextView b = tv(val, TX, 17, true); b.setPadding(0, dp(3), 0, 0); t.addView(a); t.addView(b);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.setMargins(dp(4), 0, dp(4), 0); r.addView(t, lp); return b; }

  protected void onCreate(Bundle sv) {
    super.onCreate(sv);
    getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
    FrameLayout outer = new FrameLayout(this); outer.setBackgroundColor(BG); outer.setFitsSystemWindows(true);
    LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
    TextView hd = tv("Cihaz Bilgisi", TX, 18, true); hd.setPadding(dp(16), dp(12), dp(16), dp(10)); col.addView(hd);
    nav = new Nav(this); pager = new Pager(this);
    for (int i = 0; i < 6; i++) {
      ScrollView sc = new ScrollView(this); LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(14), dp(14), dp(14), dp(118));
      sc.addView(l); pager.addView(sc, new FrameLayout.LayoutParams(-1, -1)); pg[i] = sc; pc[i] = l; }
    col.addView(pager, new LinearLayout.LayoutParams(-1, 0, 1));
    outer.addView(col, new FrameLayout.LayoutParams(-1, -1));
    FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM); nlp.setMargins(dp(10), 0, dp(10), dp(14));
    outer.addView(nav, nlp); setContentView(outer);
    sm = (SensorManager) getSystemService(SENSOR_SERVICE);
    for (int i = 0; i < 6; i++) renderPage(i, false);
    pager.layoutPages(); }

  protected void onResume() {
    super.onResume();
    for (int t : new int[]{Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GYROSCOPE, Sensor.TYPE_MAGNETIC_FIELD, Sensor.TYPE_LIGHT, Sensor.TYPE_PRESSURE, Sensor.TYPE_PROXIMITY}) {
      Sensor se = sm.getDefaultSensor(t); if (se != null) sm.registerListener(this, se, SensorManager.SENSOR_DELAY_GAME); }
    h.removeCallbacks(tick); h.postDelayed(tick, 1000);
    Choreographer.getInstance().removeFrameCallback(fcb); Choreographer.getInstance().postFrameCallback(fcb); }
  protected void onPause() { super.onPause(); sm.unregisterListener(this); h.removeCallbacks(tick); Choreographer.getInstance().removeFrameCallback(fcb); }

  public void onSensorChanged(SensorEvent e) {
    switch (e.sensor.getType()) {
      case Sensor.TYPE_ACCELEROMETER: System.arraycopy(e.values, 0, acc, 0, 3); for (int i = 0; i < 3; i++) fa[i] += .2f * (e.values[i] - fa[i]); gotAcc = true; break;
      case Sensor.TYPE_GYROSCOPE: System.arraycopy(e.values, 0, gyr, 0, 3); gotGyr = true; break;
      case Sensor.TYPE_MAGNETIC_FIELD: System.arraycopy(e.values, 0, mag, 0, 3); for (int i = 0; i < 3; i++) fm[i] += .2f * (e.values[i] - fm[i]); gotMag = true; break;
      case Sensor.TYPE_LIGHT: light = e.values[0]; break;
      case Sensor.TYPE_PRESSURE: press = e.values[0]; break;
      case Sensor.TYPE_PROXIMITY: prox = e.values[0]; break; } }
  public void onAccuracyChanged(Sensor s, int a) {}

  void renderPage(int i, boolean keep) {
    final ScrollView sc = pg[i]; final int y = sc.getScrollY(); content = pc[i]; content.removeAllViews();
    try { switch (i) { case 0: ozet(); break; case 1: donanim(); break; case 2: ekran(); break; case 3: yazilim(); break; case 4: pil(); net(); break; default: sensor(); } }
    catch (Exception e) { cardKV("Hata", "Ayrıntı", String.valueOf(e)); }
    if (keep) sc.post(() -> sc.scrollTo(0, y)); }

  // Kaydırarak sayfa değiştirme (parmağı takip eder, bırakınca yaylanarak oturur)
  class Pager extends FrameLayout {
    float pos, downX, downY, lastX; boolean drag; VelocityTracker vt; int slop; ValueAnimator va;
    Pager(Context c) { super(c); slop = ViewConfiguration.get(c).getScaledTouchSlop(); }
    protected void onSizeChanged(int w, int hh, int ow, int oh) { super.onSizeChanged(w, hh, ow, oh); layoutPages(); }
    void layoutPages() {
      int w = getWidth();
      for (int i = 0; i < pg.length; i++) { float o = i - pos; View v = pg[i];
        v.setTranslationX(o * w); v.setVisibility(Math.abs(o) < 1f ? View.VISIBLE : View.INVISIBLE); v.setAlpha(1f - .4f * Math.min(1f, Math.abs(o))); }
      if (nav != null) nav.setPos(pos); }
    void startDrag() { int r0 = Math.round(pos); for (int i = r0 - 1; i <= r0 + 1; i++) if (i >= 1 && i <= 3) renderPage(i, true); }
    void animateTo(int t) {
      if (t >= 1 && t <= 3) renderPage(t, true);
      if (va != null) va.cancel();
      float from = pos; va = ValueAnimator.ofFloat(from, t); va.setDuration((long) (360 + 80 * Math.min(3f, Math.abs(t - from))));
      va.setInterpolator(new OvershootInterpolator(.7f));
      va.addUpdateListener(a -> { pos = (Float) a.getAnimatedValue(); layoutPages(); }); va.start(); }
    public boolean onInterceptTouchEvent(MotionEvent e) {
      switch (e.getActionMasked()) {
        case MotionEvent.ACTION_DOWN: downX = lastX = e.getX(); downY = e.getY(); drag = false; if (va != null) va.cancel();
          if (vt != null) vt.recycle(); vt = VelocityTracker.obtain(); vt.addMovement(e); break;
        case MotionEvent.ACTION_MOVE: if (vt != null) vt.addMovement(e);
          if (!drag && Math.abs(e.getX() - downX) > slop && Math.abs(e.getX() - downX) > Math.abs(e.getY() - downY) * 1.3f) { drag = true; lastX = e.getX(); startDrag(); } break;
        case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: if (!drag && vt != null) { vt.recycle(); vt = null; } break; }
      return drag; }
    public boolean onTouchEvent(MotionEvent e) {
      if (vt != null) vt.addMovement(e);
      switch (e.getActionMasked()) {
        case MotionEvent.ACTION_DOWN: return true;
        case MotionEvent.ACTION_MOVE:
          if (!drag && Math.abs(e.getX() - downX) > slop && Math.abs(e.getX() - downX) > Math.abs(e.getY() - downY) * 1.3f) { drag = true; lastX = e.getX(); startDrag(); }
          if (drag) { float dx = e.getX() - lastX; lastX = e.getX(); pos = Math.max(0f, Math.min(5f, pos - dx / Math.max(1, getWidth()))); layoutPages(); }
          return true;
        case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL:
          if (drag) { float vx = 0; if (vt != null) { vt.computeCurrentVelocity(1000); vx = vt.getXVelocity(); }
            int t = Math.round(pos); if (vx < -900) t = (int) Math.floor(pos) + 1; else if (vx > 900) t = (int) Math.ceil(pos) - 1;
            animateTo(Math.max(0, Math.min(5, t))); }
          drag = false; if (vt != null) { vt.recycle(); vt = null; } return true; }
      return true; } }

  // Yüzen cam efektli alt menü: seçili alan sayfa konumunu akıcı biçimde takip eder
  class Nav extends LinearLayout {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); RectF r = new RectF(); float pos; Shader body, edge; ArgbEvaluator ev = new ArgbEvaluator(); int pad = dp(6), padH = dp(8);
    Nav(Context c) {
      super(c); setPadding(padH, pad, padH, pad); setWillNotDraw(false);
      tabs = new TextView[N.length]; ics = new Drawable[N.length];
      int[] ids = {R.drawable.i_ozet, R.drawable.i_donanim, R.drawable.i_ekran, R.drawable.i_yazilim, R.drawable.i_ag, R.drawable.i_sensor};
      for (int i = 0; i < N.length; i++) {
        final int k = i; TextView t = tv(N[i], MU, 11, false); t.setGravity(Gravity.CENTER); t.setPadding(0, dp(9), 0, dp(9)); t.setMaxLines(1);
        if (Build.VERSION.SDK_INT >= 26) t.setAutoSizeTextTypeUniformWithConfiguration(9, 12, 1, TypedValue.COMPLEX_UNIT_SP);
        Drawable d = getDrawable(ids[i]).mutate(); d.setBounds(0, 0, dp(26), dp(26)); ics[i] = d;
        t.setCompoundDrawables(null, d, null, null); t.setCompoundDrawablePadding(dp(3));
        t.setOnClickListener(v -> pager.animateTo(k)); tabs[i] = t; addView(t, new LinearLayout.LayoutParams(0, -2, 1)); }
      setPos(0); }
    void setPos(float x) {
      pos = x;
      for (int i = 0; i < tabs.length; i++) { float t = Math.max(0f, 1f - Math.abs(pos - i)); int col = (Integer) ev.evaluate(t, MU, AC);
        tabs[i].setTextColor(col); ics[i].setTint(col); tabs[i].setScaleX(1f + .04f * t); tabs[i].setScaleY(1f + .04f * t); }
      invalidate(); }
    protected void onSizeChanged(int w, int hh, int ow, int oh) { super.onSizeChanged(w, hh, ow, oh);
      body = new LinearGradient(0, 0, 0, hh, 0xFF1F292F, 0xFF131A1F, Shader.TileMode.CLAMP); edge = new LinearGradient(0, 0, 0, hh, 0x66FFFFFF, 0x14FFFFFF, Shader.TileMode.CLAMP); }
    protected void dispatchDraw(Canvas c) {
      float W = getWidth(), H = getHeight();
      if (body != null) {
        r.set(0, 0, W, H); p.setStyle(Paint.Style.FILL); p.setShader(body); c.drawRoundRect(r, H / 2, H / 2, p);
        p.setShader(edge); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); r.set(.5f * dp(1), .5f * dp(1), W - .5f * dp(1), H - .5f * dp(1)); c.drawRoundRect(r, H / 2, H / 2, p); p.setShader(null);
        int n = tabs.length; float iw = (W - 2 * padH) / n, fr = pos - (float) Math.floor(pos), st = (float) Math.sin(Math.PI * fr);
        float cx = padH + iw * (pos + .5f), hw = iw + dp(10) + st * iw * .45f, hh = H - dp(4) + st * dp(3);
        r.set(cx - hw / 2, H / 2 - hh / 2, cx + hw / 2, H / 2 + hh / 2);
        p.setStyle(Paint.Style.FILL); p.setColor(0x2E1C9FAE); c.drawRoundRect(r, hh / 2, hh / 2, p);
        p.setColor(0x24FFFFFF); c.drawRoundRect(r, hh / 2, hh / 2, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0x40FFFFFF); c.drawRoundRect(r, hh / 2, hh / 2, p); }
      super.dispatchDraw(c); } }

  String rf(String p) { try (BufferedReader r = new BufferedReader(new FileReader(p))) { return r.readLine(); } catch (Exception e) { return null; } }
  String cpuinfo(String key) {
    try (BufferedReader r = new BufferedReader(new FileReader("/proc/cpuinfo"))) { String l;
      while ((l = r.readLine()) != null) if (l.startsWith(key)) { int i = l.indexOf(':'); if (i > 0) return l.substring(i + 1).trim(); } } catch (Exception e) {} return null; }
  String gb(long b) { return String.format(Locale.US, "%.1f GB", b / 1073741824.0); }
  String f(float v) { return String.format(Locale.US, "%.2f", v); }
  long[] mem() { ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo(); ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m); return new long[]{m.totalMem, m.availMem}; }
  long[] disk() { StatFs s = new StatFs(Environment.getDataDirectory().getPath()); return new long[]{s.getTotalBytes(), s.getAvailableBytes()}; }
  // Sistem, çekirdek/GPU/yazılım için ayrılan payı düşerek bildirir; pazarlama kapasitesi bir standart boyuta yuvarlanır.
  int nom(long bytes, int[] std) { double g = bytes / 1073741824.0; for (int x : std) if (g <= x) return x; return (int) Math.ceil(g); }
  int ramNom(long b) { return nom(b, new int[]{1, 2, 3, 4, 6, 8, 10, 12, 16, 18, 24, 32}); }
  int diskNom(long b) { return nom(b, new int[]{16, 32, 64, 128, 256, 512, 1024, 2048}); }
  Intent batt() { return registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); }
  int pct() { Intent i = batt(); if (i == null) return -1; return i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / Math.max(1, i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)); }

  String socCode() {
    if (Build.VERSION.SDK_INT >= 31) { String m = Build.SOC_MODEL; if (m != null && !m.isEmpty() && !m.equals("unknown")) return m; }
    String s = cpuinfo("Hardware"); if (s != null) return s; return Build.HARDWARE; }
  String socName() {
    String code = socCode(), k = code.toLowerCase(Locale.ROOT).trim();
    String[][] T = {
      {"s5e9945", "Exynos 2400"}, {"s5e9955", "Exynos 2500"}, {"s5e9925", "Exynos 2200"}, {"s5e9840", "Exynos 2100"}, {"s5e9830", "Exynos 990"},
      {"s5e8855", "Exynos 1580"}, {"s5e8845", "Exynos 1480"}, {"s5e8835", "Exynos 1380"}, {"s5e8825", "Exynos 1280"},
      {"sm8850", "Snapdragon 8 Elite Gen 5"}, {"sm8750", "Snapdragon 8 Elite"}, {"sm8650", "Snapdragon 8 Gen 3"}, {"sm8635", "Snapdragon 8s Gen 3"},
      {"sm8550", "Snapdragon 8 Gen 2"}, {"sm8475", "Snapdragon 8+ Gen 1"}, {"sm8450", "Snapdragon 8 Gen 1"}, {"sm8350", "Snapdragon 888"}, {"sm8250", "Snapdragon 865"},
      {"sm7675", "Snapdragon 7+ Gen 3"}, {"sm7550", "Snapdragon 7 Gen 3"}, {"sm7475", "Snapdragon 7+ Gen 2"},
      {"mt6991", "Dimensity 9400"}, {"mt6989", "Dimensity 9300"}, {"mt6985", "Dimensity 9200"}, {"mt6983", "Dimensity 9000"}, {"mt6897", "Dimensity 8300"},
      {"gs101", "Google Tensor"}, {"gs201", "Google Tensor G2"}, {"zuma", "Google Tensor G3"}, {"zumapro", "Google Tensor G4"}, {"caimito", "Google Tensor G5"}};
    for (String[] t : T) if (t[0].equals(k)) {
      // Exynos 2400e ile 2400 aynı kod adını paylaşır; Galaxy S24 FE (SM-S721) 2400e kullanır.
      if (k.equals("s5e9945") && Build.MODEL.toUpperCase(Locale.ROOT).startsWith("SM-S721")) return "Exynos 2400e";
      return t[1]; }
    return code; }
  TreeMap<Integer, Integer> fmap(String f) {
    int n = Runtime.getRuntime().availableProcessors(); TreeMap<Integer, Integer> m = new TreeMap<>();
    for (int i = 0; i < n; i++) { String v = rf("/sys/devices/system/cpu/cpu" + i + "/cpufreq/" + f); if (v == null) continue;
      try { m.merge(Integer.parseInt(v.trim()) / 1000, 1, Integer::sum); } catch (Exception e) {} } return m; }
  String freqs(String f) {
    TreeMap<Integer, Integer> m = fmap(f); if (m.isEmpty()) return null; StringBuilder sb = new StringBuilder();
    for (Integer k : m.keySet()) { if (sb.length() > 0) sb.append(", "); sb.append(m.get(k)).append("×").append(k).append(" MHz"); } return sb.toString(); }
  String topo() {
    TreeMap<Integer, Integer> m = fmap("cpuinfo_max_freq"); if (m.isEmpty()) return null; StringBuilder sb = new StringBuilder();
    for (Integer k : m.descendingKeySet()) { if (sb.length() > 0) sb.append("+"); sb.append(m.get(k)); } return sb.toString(); }
  String cams() {
    try { CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE); StringBuilder sb = new StringBuilder();
      for (String id : cm.getCameraIdList()) { CameraCharacteristics c = cm.getCameraCharacteristics(id);
        Integer lf = c.get(CameraCharacteristics.LENS_FACING); Size s = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
        if (sb.length() > 0) sb.append("\n"); sb.append(id).append(": ").append(lf == null ? "?" : lf == 0 ? "Ön" : lf == 1 ? "Arka" : "Harici");
        if (s != null) sb.append(" ").append(String.format(Locale.US, "%.1f MP", s.getWidth() * (double) s.getHeight() / 1e6)); }
      return sb.length() == 0 ? null : sb.toString(); } catch (Exception e) { return null; } }
  String bst(int s) { switch (s) { case 2: return "Şarj oluyor"; case 3: return "Deşarj oluyor"; case 4: return "Şarj olmuyor"; case 5: return "Şarj tamamlandı"; default: return "Bilinmiyor"; } }
  String bsh(int s) { switch (s) { case 2: return "Şarj"; case 3: return "Deşarj"; case 4: return "Şarj yok"; case 5: return "Tamamlandı"; default: return "—"; } }
  String bhl(int s) { switch (s) { case 2: return "İyi"; case 3: return "Aşırı ısınmış"; case 4: return "Arızalı"; case 5: return "Aşırı voltaj"; case 7: return "Soğuk"; default: return "Bilinmiyor"; } }
  String bpl(int p) { if (p == 0) return "Pilden"; if ((p & 1) != 0) return "Şebeke (AC)"; if ((p & 2) != 0) return "USB"; if ((p & 4) != 0) return "Kablosuz"; return "Diğer"; }
  double inch() { DisplayMetrics dm = new DisplayMetrics(); getWindowManager().getDefaultDisplay().getRealMetrics(dm); return Math.sqrt(Math.pow(dm.widthPixels / dm.xdpi, 2) + Math.pow(dm.heightPixels / dm.ydpi, 2)); }
  String netType() {
    ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE); Network n = cm.getActiveNetwork();
    NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n); if (nc == null) return "Yok";
    return nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi" : nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Mobil veri" : nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "Ethernet" : "Diğer"; }

  // ---------- sekmeler ----------
  void ozet() {
    long[] m = mem(), d = disk(); int p = pct(); Intent bi = batt(); Display dsp = getWindowManager().getDefaultDisplay();
    String mf = Build.MANUFACTURER.substring(0, 1).toUpperCase() + Build.MANUFACTURER.substring(1);
    LinearLayout c = card(null);
    c.addView(tv(mf.toUpperCase(), MU, 11, true)); c.addView(tv(Build.MODEL, TX, 22, true));
    TextView s1 = tv("Android " + Build.VERSION.RELEASE + " · API " + Build.VERSION.SDK_INT + " · Yama " + Build.VERSION.SECURITY_PATCH, MU, 12, false); s1.setPadding(0, dp(2), 0, dp(12)); c.addView(s1);
    View ln = new View(this); ln.setBackgroundColor(LINE); c.addView(ln, new LinearLayout.LayoutParams(-1, dp(1)));
    TextView l2 = tv("İŞLEMCİ", AC, 11, true); l2.setPadding(0, dp(12), 0, 0); c.addView(l2);
    c.addView(tv(socName(), TX, 24, true));
    TreeMap<Integer, Integer> fm0 = fmap("cpuinfo_max_freq"); String tp = topo();
    TextView s2 = tv(Runtime.getRuntime().availableProcessors() + " çekirdek" + (tp != null ? " (" + tp + ")" : "") + (fm0.isEmpty() ? "" : " · en yüksek " + String.format(Locale.US, "%.2f GHz", fm0.lastKey() / 1000.0)), MU, 12, false);
    s2.setPadding(0, dp(2), 0, dp(8)); c.addView(s2);
    int ru = 100 - (int) (m[1] * 100 / m[0]), du = 100 - (int) (d[1] * 100 / d[0]);
    int st = bi == null ? 1 : bi.getIntExtra(BatteryManager.EXTRA_STATUS, 1);
    c = card("Kullanım"); LinearLayout r = new LinearLayout(this); c.addView(r);
    String[] lb = {"RAM", "Depolama", "Pil"}; String[] sb = {gb(m[0] - m[1]).replace(" GB", "") + " / " + ramNom(m[0]) + " GB", gb(d[0] - d[1]).replace(" GB", "") + " / " + diskNom(d[0]) + " GB", bsh(st)}; int[] pv = {ru, du, p};
    for (int i = 0; i < 3; i++) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1); lp.setMargins(dp(4), 0, dp(4), 0); r.addView(new Ring(this, lb[i], sb[i], pv[i], ringStore, i), lp); }
    LinearLayout r1 = hrow(); tile(r1, "Ekran", String.format(Locale.US, "%.1f inç", inch())); tile(r1, "Yenileme", String.format(Locale.US, "%.0f Hz", dsp.getRefreshRate()));
    LinearLayout r2 = hrow(); tile(r2, "Pil sıcaklığı", bi == null ? "—" : (bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0) + " °C"); tile(r2, "Bağlantı", netType());
    long up = SystemClock.elapsedRealtime() / 1000;
    LinearLayout r3 = hrow(); tile(r3, "Açık kalma", (up / 3600) + " sa " + ((up % 3600) / 60) + " dk"); tile(r3, "Bellek", ramNom(m[0]) + " GB · " + diskNom(d[0]) + " GB"); }

  void donanim() {
    long[] m = mem(), d = disk(); ConfigurationInfo ci = ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getDeviceConfigurationInfo();
    cardKV("İşlemci", "Model", socName(), "Kod adı", socCode(), "Kart (board)", Build.BOARD, "Donanım", Build.HARDWARE, "Çekirdek sayısı", "" + Runtime.getRuntime().availableProcessors(),
      "Maks. frekans", freqs("cpuinfo_max_freq"), "Anlık frekans", freqs("scaling_cur_freq"), "Mimari (ABI)", String.join(", ", Build.SUPPORTED_ABIS));
    cardKV("Bellek ve Depolama", "RAM", ramNom(m[0]) + " GB", "RAM (sistemin gördüğü)", gb(m[0]), "RAM kullanılabilir", gb(m[1]), "Depolama", diskNom(d[0]) + " GB", "Depolama (kullanıcı alanı)", gb(d[0]), "Boş alan", gb(d[1]));
    cardKV("Grafik", "OpenGL ES", ci.getGlEsVersion(), "Vulkan", getPackageManager().hasSystemFeature("android.hardware.vulkan.version") ? "Var" : "Yok");
    cardKV("Kameralar", "Liste", cams());
    String[][] F = {{"NFC", "android.hardware.nfc"}, {"Bluetooth", "android.hardware.bluetooth"}, {"Bluetooth LE", "android.hardware.bluetooth_le"}, {"Wi-Fi", "android.hardware.wifi"},
      {"GPS", "android.hardware.location.gps"}, {"Parmak izi", "android.hardware.fingerprint"}, {"Telefon", "android.hardware.telephony"}, {"Kızılötesi", "android.hardware.consumerir"},
      {"Çoklu dokunma", "android.hardware.touchscreen.multitouch"}, {"USB host", "android.hardware.usb.host"}, {"Kamera flaşı", "android.hardware.camera.flash"}};
    LinearLayout c = card("Özellikler"); for (String[] x : F) row(c, x[0], getPackageManager().hasSystemFeature(x[1]) ? "Var" : "Yok"); }

  void ekran() {
    DisplayMetrics dm = new DisplayMetrics(); Display d = getWindowManager().getDefaultDisplay(); d.getRealMetrics(dm);
    TreeSet<Integer> hz = new TreeSet<>(); for (Display.Mode m : d.getSupportedModes()) hz.add(Math.round(m.getRefreshRate()));
    cardKV("Panel", "Çözünürlük", dm.widthPixels + " × " + dm.heightPixels, "Ekran boyutu", String.format(Locale.US, "%.1f inç", inch()), "Yoğunluk", dm.densityDpi + " dpi",
      "Ölçek", dm.density + "x", "Yenileme hızı", String.format(Locale.US, "%.0f Hz", d.getRefreshRate()), "Desteklenen modlar", hz.toString().replace("[", "").replace("]", "") + " Hz",
      "Yönelim", getResources().getConfiguration().orientation == 2 ? "Yatay" : "Dikey", "Ekran adı", d.getName()); }

  void yazilim() {
    long up = SystemClock.elapsedRealtime() / 1000;
    cardKV("Android", "Sürüm", Build.VERSION.RELEASE, "API seviyesi", "" + Build.VERSION.SDK_INT, "Güvenlik yaması", Build.VERSION.SECURITY_PATCH, "Derleme", Build.DISPLAY, "Artımlı", Build.VERSION.INCREMENTAL, "Tür / Etiket", Build.TYPE + " / " + Build.TAGS);
    cardKV("Sistem", "Çekirdek (kernel)", System.getProperty("os.version"), "Bootloader", Build.BOOTLOADER, "Java VM", System.getProperty("java.vm.version"),
      "Açık kalma süresi", (up / 3600) + " sa " + ((up % 3600) / 60) + " dk", "Dil", Locale.getDefault().toString(), "Saat dilimi", java.util.TimeZone.getDefault().getID());
    cardKV("Üretici", "Marka", Build.BRAND, "Üretici", Build.MANUFACTURER, "Cihaz kodu", Build.DEVICE, "Ürün", Build.PRODUCT, "Parmak izi (fingerprint)", Build.FINGERPRINT); }

  void pil() {
    Intent i = batt(); if (i == null) { cardKV("Pil", "Durum", "Okunamadı"); return; }
    int p = pct(); LinearLayout c = card("Pil"); row(c, "Seviye", "%" + p); bar(c, p);
    row(c, "Durum", bst(i.getIntExtra(BatteryManager.EXTRA_STATUS, 1))); row(c, "Güç kaynağı", bpl(i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)));
    row(c, "Sağlık", bhl(i.getIntExtra(BatteryManager.EXTRA_HEALTH, 1))); row(c, "Sıcaklık", (i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0) + " °C");
    row(c, "Voltaj", i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) + " mV"); row(c, "Teknoloji", i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)); }

  void net() {
    ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE); Network n = cm.getActiveNetwork();
    NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
    if (nc == null) { cardKV("Bağlantı", "Durum", "Bağlantı yok"); return; }
    cardKV("Bağlantı", "Durum", "Bağlı", "Tür", netType(), "İndirme (tahmini)", nc.getLinkDownstreamBandwidthKbps() / 1000 + " Mbps", "Yükleme (tahmini)", nc.getLinkUpstreamBandwidthKbps() / 1000 + " Mbps",
      "İnternet", nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ? "Doğrulandı" : "Doğrulanamadı", "VPN", nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ? "Var" : "Yok"); }

  void sensor() {
    LinearLayout c = card("Pusula"); cp = new Compass(this); c.addView(cp, new LinearLayout.LayoutParams(-1, dp(270)));
    c = card("İvmeölçer (m/s²)"); ax = new Axis(this, 20); c.addView(ax, new LinearLayout.LayoutParams(-1, dp(96)));
    c = card("Jiroskop (rad/s)"); gy = new Axis(this, 8); c.addView(gy, new LinearLayout.LayoutParams(-1, dp(96)));
    c = card("Manyetometre (µT)"); mg = new Axis(this, 100); c.addView(mg, new LinearLayout.LayoutParams(-1, dp(96)));
    LinearLayout r = hrow(); tLux = tile(r, "Işık (lx)", "—"); tHpa = tile(r, "Basınç (hPa)", "—"); tProx = tile(r, "Yakınlık (cm)", "—");
    List<Sensor> l = sm.getSensorList(Sensor.TYPE_ALL); c = card("Cihazdaki Sensörler (" + l.size() + ")");
    for (Sensor s : l) {
      String t = s.getStringType(); t = t.substring(t.lastIndexOf('.') + 1).replace('_', ' ');
      if (c.getChildCount() > 1) { View ln = new View(this); ln.setBackgroundColor(LINE); c.addView(ln, new LinearLayout.LayoutParams(-1, dp(1))); }
      LinearLayout rr = new LinearLayout(this); rr.setOrientation(LinearLayout.VERTICAL); rr.setPadding(0, dp(9), 0, dp(9));
      TextView a = tv(t.toUpperCase(Locale.ROOT), AC, 10, true); TextView b = tv(s.getName(), TX, 13, false); TextView v = tv(s.getVendor(), MU, 11, false);
      rr.addView(a); rr.addView(b); rr.addView(v); c.addView(rr); } }

  // Her ekran karesinde değerler hedefe doğru yumuşakça yaklaşır (akıcı hareket)
  void frame(float dt) {
    if (pager == null || pager.pos < 4.001f || cp == null) return;
    float a = 1f - (float) Math.exp(-dt * 16), b = 1f - (float) Math.exp(-dt * 9);
    for (int i = 0; i < 3; i++) { dAcc[i] += (acc[i] - dAcc[i]) * a; dGyr[i] += (gyr[i] - dGyr[i]) * a; dMag[i] += (mag[i] - dMag[i]) * a; }
    float hd = Float.NaN;
    if (gotAcc && gotMag) { float[] R = new float[9], o = new float[3]; if (SensorManager.getRotationMatrix(R, null, fa, fm)) { SensorManager.getOrientation(R, o); hd = (float) ((Math.toDegrees(o[0]) + 360) % 360); } }
    if (Float.isNaN(hd)) hdD = Float.NaN; else if (Float.isNaN(hdD)) hdD = hd; else { float df = ((hd - hdD + 540f) % 360f) - 180f; hdD = (hdD + df * b + 360f) % 360f; }
    cp.set(hdD); ax.set(dAcc, gotAcc); gy.set(dGyr, gotGyr); mg.set(dMag, gotMag);
    if (++fcnt % 8 == 0) {
      tLux.setText(light < 0 ? "—" : String.format(Locale.US, "%.0f", light)); tHpa.setText(press < 0 ? "—" : String.format(Locale.US, "%.1f", press)); tProx.setText(prox < 0 ? "—" : String.format(Locale.US, "%.1f", prox)); } }
}
